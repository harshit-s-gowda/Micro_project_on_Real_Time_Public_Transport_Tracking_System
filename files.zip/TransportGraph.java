import java.util.*;

public class TransportGraph {

    private final Map<String, BusStop>      stops     = new LinkedHashMap<>();
    private final Map<String, List<Edge>>   adjacency = new LinkedHashMap<>();

    public void addStop(BusStop stop) {
        stops.put(stop.getId(), stop);
        adjacency.putIfAbsent(stop.getId(), new ArrayList<>());
    }

    public void addEdge(String srcId, String dstId, double weight, String route) {
        BusStop src  = stops.get(srcId);
        BusStop dst  = stops.get(dstId);
        if (src == null || dst == null)
            throw new IllegalArgumentException("Stop not found: " + srcId + " / " + dstId);
        adjacency.get(srcId).add(new Edge(src, dst, weight, route));
    }

    public void addBidirectionalEdge(String a, String b, double weight, String route) {
        addEdge(a, b, weight, route);
        addEdge(b, a, weight, route);
    }

    public BusStop             getStop(String id)    { return stops.get(id); }
    public Collection<BusStop> getAllStops()         { return stops.values(); }
    public List<Edge>          getEdges(String id)   { return adjacency.getOrDefault(id, Collections.emptyList()); }
    public boolean             containsStop(String id){ return stops.containsKey(id); }
    public int                 stopCount()           { return stops.size(); }
    public int edgeCount() {
        return adjacency.values().stream().mapToInt(List::size).sum();
    }

    public List<Edge> getAllEdges() {
        List<Edge> all = new ArrayList<>();
        adjacency.values().forEach(all::addAll);
        return all;
    }

    @Override public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Transport Graph ===\n");
        sb.append(String.format("Stops: %d  |  Edges: %d%n%n", stopCount(), edgeCount()));
        for (BusStop stop : stops.values()) {
            sb.append(stop).append("\n");
            for (Edge e : adjacency.get(stop.getId()))
                sb.append("    ").append(e).append("\n");
        }
        return sb.toString();
    }
}
