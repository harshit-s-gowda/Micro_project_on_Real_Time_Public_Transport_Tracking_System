import java.util.*;

/**
 * Dijkstra's Shortest Path Algorithm
 * ------------------------------------
 * Time Complexity  : O((V + E) log V)  — min-heap / Priority Queue
 * Space Complexity : O(V)
 *
 * Works ONLY with non-negative edge weights.
 *
 * Steps:
 *  1. dist[source]=0, all others = INFINITY
 *  2. Push (0, source) into min-priority queue
 *  3. While queue not empty:
 *       u = extract node with minimum dist
 *       For each neighbour v of u:
 *         if dist[u] + w(u,v) < dist[v]:  relax & push
 *  4. Reconstruct path via prev[]
 */
public class DijkstraAlgorithm {

    public RouteResult findShortestPath(TransportGraph graph, String sourceId, String destId) {

        long startTime = System.nanoTime();

        Map<String, Double> dist = new HashMap<>();
        Map<String, String> prev = new HashMap<>();

        for (BusStop s : graph.getAllStops()) {
            dist.put(s.getId(), Double.MAX_VALUE);
            prev.put(s.getId(), null);
        }
        dist.put(sourceId, 0.0);

        // Min-heap: [distance, stopId]
        PriorityQueue<StopEntry> minHeap = new PriorityQueue<>(Comparator.comparingDouble(e -> e.dist));
        minHeap.add(new StopEntry(0.0, sourceId));

        Set<String> settled   = new HashSet<>();
        int[]       visited   = {0};

        while (!minHeap.isEmpty()) {
            StopEntry cur = minHeap.poll();
            String u = cur.stopId;

            if (settled.contains(u)) continue;
            settled.add(u);
            visited[0]++;

            if (u.equals(destId)) break;

            for (Edge edge : graph.getEdges(u)) {
                String v       = edge.getDestination().getId();
                double newDist = dist.get(u) + edge.getWeight();
                if (newDist < dist.get(v)) {
                    dist.put(v, newDist);
                    prev.put(v, u);
                    minHeap.add(new StopEntry(newDist, v));
                }
            }
        }

        long elapsed   = System.nanoTime() - startTime;
        boolean found  = dist.get(destId) < Double.MAX_VALUE;
        List<BusStop> path = new ArrayList<>();

        if (found) {
            for (String at = destId; at != null; at = prev.get(at))
                path.add(0, graph.getStop(at));
        }

        return new RouteResult(path, found ? dist.get(destId) : 0,
                RouteResult.Algorithm.DIJKSTRA, elapsed, visited[0], found);
    }

    private static class StopEntry {
        double dist; String stopId;
        StopEntry(double d, String s) { dist = d; stopId = s; }
    }
}
