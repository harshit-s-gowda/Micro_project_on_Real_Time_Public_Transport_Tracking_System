import java.util.*;

public class ConsoleUI {

    private static final String BANNER =
        "╔══════════════════════════════════════════════════════════╗\n" +
        "║  REAL-TIME PUBLIC TRANSPORT ROUTE FINDER  (SIH25013)    ║\n" +
        "║       Bengaluru Bus Network  |  DAA Mini Project         ║\n" +
        "╚══════════════════════════════════════════════════════════╝";

    private final TransportGraph     graph      = GraphBuilder.buildBengaluruNetwork();
    private final DijkstraAlgorithm  dijkstra   = new DijkstraAlgorithm();
    private final BellmanFordAlgorithm bellman  = new BellmanFordAlgorithm();
    private final Scanner            sc         = new Scanner(System.in);

    public void run() {
        System.out.println(BANNER);
        System.out.printf("%nNetwork loaded: %d stops, %d directed edges%n",
                graph.stopCount(), graph.edgeCount());

        while (true) {
            printMenu();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1" -> runAlgorithm("DIJKSTRA");
                case "2" -> runAlgorithm("BELLMAN_FORD");
                case "3" -> compareAlgorithms();
                case "4" -> listStops();
                case "5" -> System.out.println(graph);
                case "6" -> complexityReport();
                case "0" -> { System.out.println("\n  Goodbye!"); return; }
                default  -> System.out.println("  Invalid option, try again.");
            }
        }
    }

    // ── Menu ────────────────────────────────────────────────────────────────

    private void printMenu() {
        System.out.println("\n┌──────────────────────────────────────────┐");
        System.out.println("│            MAIN MENU                     │");
        System.out.println("│  1. Find shortest route  [Dijkstra]      │");
        System.out.println("│  2. Find shortest route  [Bellman-Ford]  │");
        System.out.println("│  3. Compare both algorithms              │");
        System.out.println("│  4. List all bus stops                   │");
        System.out.println("│  5. Show full graph (adjacency list)     │");
        System.out.println("│  6. Time & Space complexity report       │");
        System.out.println("│  0. Exit                                 │");
        System.out.println("└──────────────────────────────────────────┘");
        System.out.print("  Enter choice: ");
    }

    // ── Route finding ───────────────────────────────────────────────────────

    private void runAlgorithm(String algo) {
        listStops();
        String src  = promptStop("SOURCE stop ID");
        String dest = promptStop("DESTINATION stop ID");

        RouteResult result = algo.equals("DIJKSTRA")
                ? dijkstra.findShortestPath(graph, src, dest)
                : bellman.findShortestPath(graph, src, dest);

        System.out.println("\n" + "─".repeat(55));
        System.out.println(result);
        System.out.println("─".repeat(55));
    }

    // ── Comparison ──────────────────────────────────────────────────────────

    private void compareAlgorithms() {
        listStops();
        String src  = promptStop("SOURCE stop ID");
        String dest = promptStop("DESTINATION stop ID");

        RouteResult dr = dijkstra.findShortestPath(graph, src, dest);
        RouteResult br = bellman.findShortestPath(graph, src, dest);

        System.out.println("\n" + "═".repeat(60));
        System.out.printf("  COMPARISON:  %s  -->  %s%n",
                graph.getStop(src).getName(), graph.getStop(dest).getName());
        System.out.println("═".repeat(60));

        printCompact("DIJKSTRA",     dr);
        System.out.println();
        printCompact("BELLMAN-FORD", br);

        System.out.println("\n" + "─".repeat(60));
        System.out.printf("  %-20s  %-22s  %s%n", "Algorithm", "Time Complexity", "Space");
        System.out.printf("  %-20s  %-22s  %s%n", "Dijkstra",   "O((V+E) log V)", "O(V)");
        System.out.printf("  %-20s  %-22s  %s%n", "Bellman-Ford","O(V x E)",       "O(V)");

        int V = graph.stopCount(), E = graph.edgeCount();
        System.out.printf("%n  With V=%d, E=%d:%n", V, E);
        System.out.printf("    Dijkstra ops    ~ %,d%n", (long)((V+E) * (Math.log(V)/Math.log(2))));
        System.out.printf("    Bellman-Ford ops~ %,d%n", (long) V * E);
        System.out.println("═".repeat(60));
    }

    private void printCompact(String label, RouteResult r) {
        System.out.println("  [" + label + "]");
        if (!r.isPathExists()) { System.out.println("  No path found."); return; }
        System.out.printf("  Cost       : %.1f min%n", r.getTotalWeight());
        System.out.printf("  Exec time  : %s%n", r.getFormattedTime());
        System.out.printf("  Nodes proc.: %d%n", r.getNodesVisited());
        System.out.print("  Path       : ");
        List<BusStop> p = r.getPath();
        for (int i = 0; i < p.size(); i++) {
            System.out.print(p.get(i).getName());
            if (i < p.size()-1) System.out.print(" -> ");
        }
        System.out.println();
    }

    // ── Complexity report ───────────────────────────────────────────────────

    private void complexityReport() {
        int V = graph.stopCount(), E = graph.edgeCount();
        System.out.println("\n" + "═".repeat(60));
        System.out.println("  TIME & SPACE COMPLEXITY ANALYSIS");
        System.out.println("═".repeat(60));
        System.out.printf("  Network: V=%d vertices (stops), E=%d edges%n%n", V, E);
        System.out.printf("  %-20s %-22s %-8s%n","Algorithm","Time","Space");
        System.out.println("  " + "─".repeat(52));
        System.out.printf("  %-20s %-22s %-8s%n","Dijkstra (heap)","O((V+E) log V)","O(V)");
        System.out.printf("  %-20s %-22s %-8s%n","Bellman-Ford","O(V x E)","O(V)");
        System.out.println();
        System.out.println("  KEY DIFFERENCES:");
        System.out.println("  * Dijkstra  - Greedy, uses min-heap, non-negative weights only");
        System.out.println("  * Bellman-Ford - Dynamic programming, handles negative weights,");
        System.out.println("    can detect negative-weight cycles");
        System.out.println("  * For real-world transport: Dijkstra preferred (faster, no neg weights)");
        System.out.println("  * Both use O(V) extra space for dist[] and prev[] arrays");
        System.out.println("═".repeat(60));
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private void listStops() {
        System.out.println("\n  BUS STOPS:");
        System.out.println("  " + "─".repeat(38));
        for (BusStop s : graph.getAllStops())
            System.out.printf("  %-5s  %s%n", s.getId(), s.getName());
        System.out.println("  " + "─".repeat(38));
    }

    private String promptStop(String label) {
        while (true) {
            System.out.print("  Enter " + label + ": ");
            String id = sc.nextLine().trim().toUpperCase();
            if (graph.containsStop(id)) return id;
            System.out.println("  Stop '" + id + "' not found. Please try again.");
        }
    }
}
